package com.saikiran.smartshop.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.saikiran.smartshop.entity.Product;
import com.saikiran.smartshop.service.ProductService;
import com.saikiran.smartshop.service.serviceImpl.ProductServiceImpl;

@Controller
public class ProductController {
	@Autowired
	ProductService productServiceImpl;
	
	@GetMapping("/getAllProducts")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		return new ResponseEntity<>( productServiceImpl.getAllProducts(),HttpStatus.OK);
		
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity< Product> addProduct(@RequestBody Product product){
		
		return new ResponseEntity<>( productServiceImpl.addProduct(product),HttpStatus.CREATED);
		
	}
	@GetMapping("/findByProductName/{productName}")
	public ResponseEntity<List<Product>> findByProductName(@PathVariable("productName") String productname){
		
		return new ResponseEntity<>( productServiceImpl.findByProductName(productname),HttpStatus.OK);
		
	}
	@GetMapping("/findByCategory/{category}")
	public ResponseEntity<List<Product>> findByProductId(@PathVariable("category") String category){
		
		return new ResponseEntity<>( productServiceImpl.findByCategory(category),HttpStatus.OK);
		
	}
    @PutMapping("/updateProduct/{productId}")
    	public ResponseEntity<Product> updateProduct(@PathVariable("productId") int id, @RequestBody Product product) {
    	return new ResponseEntity<>( productServiceImpl.updateProduct(id, product),HttpStatus.OK);
    		
    	}
    
   @GetMapping("/TotalPrice/{productId}")
   public ResponseEntity<Integer> totalPriceForProduct(@PathVariable("productId") int id) {
   	return new ResponseEntity<>( productServiceImpl.calculateTotalPrce(id),HttpStatus.OK);
   		
   	}
   @DeleteMapping("/deleteProduct")
   public  void deleteProductById() {
	   productServiceImpl.deleteProduct();
	  
   }

}

