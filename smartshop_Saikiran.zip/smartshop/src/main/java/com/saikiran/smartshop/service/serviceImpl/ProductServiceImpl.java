package com.saikiran.smartshop.service.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saikiran.smartshop.entity.Product;
import com.saikiran.smartshop.exception.ResourceNotFoundException;
import com.saikiran.smartshop.repository.ProductRepository;
import com.saikiran.smartshop.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	static final Log log  =LogFactory.getLog(ProductServiceImpl.class);
	@Autowired
	ProductRepository repo;

	@Override
	public List<Product> getAllProducts() throws ResourceNotFoundException{
		List<Product> products =repo.findAll();
		log.info("getting list of products "+products);
		if(products.isEmpty()) {
			throw new ResourceNotFoundException("failed to get list of products");
		}
		return products;
	}

	@Override
	public Product addProduct(Product product) throws ResourceNotFoundException {
		Product addedProduct =repo.save(product);
		log.info("product added "+addedProduct);
		return addedProduct;
		
	}

	

	@Override
	public List<Product> findByProductName(String productName) throws ResourceNotFoundException{
		List<Product> productByName =repo.findByProductName(productName);
		log.info("list of products by product name "+productByName);
		if(productByName.isEmpty()) {
			throw new ResourceNotFoundException("No data avalible for given product name");
		}
		return productByName;
	}

	@Override
	public List<Product> findByCategory(String category) throws ResourceNotFoundException{
		List<Product> productByCategory =repo.findByCategory(category);
		log.info("list of products by category "+productByCategory);
		if(productByCategory.isEmpty()) {
			throw new ResourceNotFoundException("No data avalible for given product id");
		}
		return productByCategory;
	}

	@Override
	public Product updateProduct(int productId, Product product)throws ResourceNotFoundException  {
		Optional<Product> products=repo.findById(productId);
		log.info("product by id "+products);
		Product productObj = new Product();
		
		if(products.isPresent()) {
			productObj.setProductId(product.getProductId());
			productObj.setCategory(product.getCategory());
			productObj.setProductName(product.getProductName());
			productObj.setQuantity(product.getQuantity());
			productObj.setRatings(product.getRatings());
			productObj.setTotalPrice(product.getTotalPrice());
			productObj.setUnitPrice(product.getUnitPrice());
			repo.save(productObj);
		}if(!products.isPresent()) {
			throw new ResourceNotFoundException("Invalid productId");
		}
		return productObj;
		
		
	}

	@Override
	public int calculateTotalPrce(int productId) throws ResourceNotFoundException  {
		Optional<Product> products=repo.findById(productId);
		log.info("product by id "+products);
		Product product = new Product();
		int totalPrice=0;
	    if(products.isPresent()) {
			
			int unitPrice=product.getUnitPrice();
			int  quntity=product.getQuantity();
			totalPrice=unitPrice * quntity;
			product.setTotalPrice(totalPrice);
			
		}
	    if(!products.isPresent()) {
	    	throw new ResourceNotFoundException("Invalid productId");
	    }
		return totalPrice;
	}

	@Override
	public void deleteProduct() throws ResourceNotFoundException {
	      List<Product> products=repo.findAll().stream().filter(r ->(r.getRatings() < 2)).collect(Collectors.toList());
	      log.info("List of products where ratings is below 2  "+products);
			if(products.isEmpty()) {
				throw new ResourceNotFoundException("No products is available under 2 ratings");
			}
			for(Product product : products) {
				repo.delete(product);
			}
				
		
	}

}
