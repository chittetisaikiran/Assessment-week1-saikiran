package com.saikiran.smartshop.service;

import java.util.List;

import com.saikiran.smartshop.entity.Product;

public interface ProductService {
	
 List<Product>getAllProducts();
 Product addProduct(Product product);
 List<Product> findByProductName(String productName);
 List<Product> findByCategory(String category);
 Product updateProduct(int productId, Product product);
  int calculateTotalPrce(int productId);
  void deleteProduct();
}
